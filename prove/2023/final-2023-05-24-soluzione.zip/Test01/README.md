Questo file contiene una possibile soluzione agli esercizi della simulazione.

Ci sono molti commenti e stampe per facilitarne il testing agli studenti che avessero dubbi ma, a meno che siano ESPLICITAMENTE richiesti nel testo dell'esame, non dovete farli.

Potete comunque fare print per testare il vostro codice o fare debugging rapido se qualcosa non funziona.

Per eseguire diversi esercizi è chiesto inizialmente di interagire col programma via riga di comando, per prima cosa inserendo il numero di esercizio.

- Matteo Belletti 
- mail: matteo.belletti10@unibo.it
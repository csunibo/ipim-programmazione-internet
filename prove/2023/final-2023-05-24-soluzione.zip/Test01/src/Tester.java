public class Tester {
    static int globalCounter = 0;
    private int counter = 0;
    private String name = "";
    public Tester(int counter, String name){
        this.counter = counter;
        this.name = name;
    }
    public static int getGlobalCounter(){
        return globalCounter;
    }
    public static void increaseGlobalCounter(int n){
        globalCounter += n;
    }
    public static void increaseGlobalCounter(){
        globalCounter += 1;
    }

    public String getName(){
        return this.name;
    }

    public int getPrivateCounter(){
        return this.counter;
    }

    public void setPrivateCounter(int n){
        this.counter = n;
    }
    // public static void main(String[] args) {
        
    //     // Tester tester = new Tester(10, "Miao");
    //     // System.err.println(tester.getName());
    //     // System.err.println(tester.getPrivateCounter());
    //     // tester.setPrivateCounter(100);
    //     // System.err.println(tester.getPrivateCounter());
    //     // Tester.increaseGlobalCounter(4);
    //     // System.err.println(Tester.getGlobalCounter());
    //     // System.err.println(tester.getGlobalCounter());
    // }
}
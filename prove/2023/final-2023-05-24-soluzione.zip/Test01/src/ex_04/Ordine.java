package ex_04;

import java.util.ArrayList;

public class Ordine {
    //generate random id
    private String idOrdine;
    private ArrayList<Articolo> articoli;
    private double prezzoTotale;

    public Ordine(String idOrdine){
        this.idOrdine = idOrdine;
        this.articoli = new ArrayList<Articolo>();
        this.prezzoTotale = 0;
    }

    public Ordine(Articolo a, String idOrdine){
        this.idOrdine = String.valueOf((int)(Math.random() * 1000));
        this.articoli = new ArrayList<Articolo>();
        this.aggiungiArticolo(a);
        this.prezzoTotale = 0;
    }

    public void aggiungiArticolo(Articolo a){
        this.articoli.add(a);
        this.prezzoTotale += a.getPrezzo();
    }

    public double getPrezzoTotale(){
        return this.prezzoTotale;
    }

    public String getIdOrdine(){
        return this.idOrdine;
    }

    public ArrayList<Articolo> getArticoli(){
        return this.articoli;
    }

    public String printInfo(){
        String info = "ORDINE: " + this.idOrdine + "\n\n";
        info += "Articoli: \n\n";
        int i = 1;
        for (Articolo articolo : articoli) {
            info += i + ") " + articolo.getInfo() + "\n";
            i++;
        }
        info += "\nPrezzo totale ordine: " + this.prezzoTotale + "\n";
        info += "----------------------------------\n";

        return info;
    }
}

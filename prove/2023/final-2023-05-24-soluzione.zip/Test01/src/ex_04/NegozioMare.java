package ex_04;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;

/**
 * NegozioMare
 */
public class NegozioMare {
    private final String exportDir = System.getProperty("user.dir") + File.separator + "Test01" + File.separator + "src" + File.separator + "exports" + File.separator;
    private LinkedList<Ordine> ordini;

    public NegozioMare() {
        this.ordini = new LinkedList<Ordine>();
    }

    public void aggiungiOrdine(Ordine o){
        if (o != null) {
            if (o.getPrezzoTotale() > 500) {
                this.ordini.addLast(o);
            } else {
                this.ordini.addFirst(o);
            }
        }
    }

    public Boolean exportOrdini(int nOrdini){
        if (nOrdini < 0) {
            return false;
        } else {
            // salvo il file con nome ordine + timestamp per comodità
            String fileName = "ordine" + System.currentTimeMillis() + ".txt";
            String fileContent = "";
            for (int i = 0; i < nOrdini; i++) {
                if (this.ordini.size() > i) {
                    fileContent += this.ordini.get(i).printInfo();
                }
            }
            try {
                Path path = Paths.get(exportDir + File.separator + fileName);
                java.nio.file.Files.write(path, fileContent.getBytes());
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
        return true;
    }
}
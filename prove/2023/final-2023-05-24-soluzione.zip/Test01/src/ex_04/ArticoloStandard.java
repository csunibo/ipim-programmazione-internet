package ex_04;

public class ArticoloStandard implements Articolo{

    private String idArticolo;
    private double prezzo;

    public ArticoloStandard(String idArticolo, double prezzo) {
        this.idArticolo = idArticolo;
        this.prezzo = prezzo;
    }
    
    @Override
    public double getPrezzo() {
        return prezzo;
    }

    @Override
    public String getId() {
        return idArticolo;
    }

    @Override
    public String getInfo(){
        return "Articolo: " + this.idArticolo + " - Prezzo: " + this.prezzo;
    }
}

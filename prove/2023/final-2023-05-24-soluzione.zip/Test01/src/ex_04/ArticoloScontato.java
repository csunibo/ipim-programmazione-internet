package ex_04;

public class ArticoloScontato implements Articolo{
    private String idArticolo;
    private double prezzo;
    private double sconto;

    public ArticoloScontato(String idArticolo, double prezzo, double sconto) {
        this.idArticolo = idArticolo;
        this.prezzo = prezzo;
        this.sconto = sconto;
    }

    @Override
    public double getPrezzo() {
        return prezzo - (prezzo * sconto);
    }

    @Override
    public String getId() {
        return idArticolo;
    }

    @Override
    public String getInfo(){
        return "Articolo: " + this.idArticolo + " - Prezzo: " + this.prezzo;
    }
}

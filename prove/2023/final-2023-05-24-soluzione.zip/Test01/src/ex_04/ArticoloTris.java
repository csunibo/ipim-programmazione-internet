package ex_04;

public class ArticoloTris implements Articolo{
    private double prezzo = 0;
    private ArticoloStandard[] articoli;

    public ArticoloTris(ArticoloStandard[] articoli) {
        this.articoli = articoli;
        double min = 0;
        for (int i = 0; i < 3; i++) {
            if (articoli[i].getPrezzo() < min) {
                min = articoli[i].getPrezzo();
            }
            prezzo += articoli[i].getPrezzo();
        }
        prezzo -= min;
    }

    @Override
    public double getPrezzo() {
        return prezzo;
    }

    @Override
    public String getId() {
        return this.articoli[0].getId() + "," + this.articoli[1].getId() + "," + this.articoli[2].getId();

    }

    @Override
    public String getInfo(){
        return "Articolo tris:\n" + 
               "- " + this.articoli[0].getId() + " - Prezzo: " + this.articoli[0].getPrezzo() + "\n" +
               "- " + this.articoli[1].getId() + " - Prezzo: " + this.articoli[1].getPrezzo() + "\n" +
               "- " + this.articoli[2].getId() + " - Prezzo: " + this.articoli[2].getPrezzo() + "\n" +
               "Prezzo finale (meno caro in offerta): " + this.prezzo + "\n";
    }
}

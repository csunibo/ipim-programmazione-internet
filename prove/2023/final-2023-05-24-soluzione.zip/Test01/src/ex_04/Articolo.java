package ex_04;

public interface Articolo {
    public double getPrezzo();
    public String getId();
    public String getInfo();
}

import java.util.ArrayList;
import java.util.Random;

import ex_04.ArticoloScontato;
import ex_04.ArticoloStandard;
import ex_04.ArticoloTris;
import ex_04.NegozioMare;
import ex_04.Ordine;

public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println("Scegli un esercizio: ");
        int choice = Integer.parseInt(System.console().readLine());
        switch (choice) {
            case 1:
                System.out.println("ESERCIZIO 1: inserire una sequenza di interi positivi, terminata da un intero negativo.");
                ArrayList<Integer> arr = new ArrayList<Integer>();
                while(true){
                    int i = Integer.parseInt(System.console().readLine());
                    if(i < 0){
                        break;
                    } else {
                        arr.add(i);
                    }
                }
                int element = arr.get(0);
                int index = 0;
                while (element != index && element < arr.size()) {
                    System.out.println(element);
                    index = element;
                    element = arr.get(index);
                }
                System.out.println(element);
                break;

            case 2:
                System.out.println("ESERCIZIO 2: inserire dimensioni di due matrici");
                int rows = Integer.parseInt(System.console().readLine());
                int cols = Integer.parseInt(System.console().readLine());
                int[][] matrix = new int[rows][cols];
                for(int i = 0; i < rows; i++){
                    for(int j = 0; j < cols; j++){
                        // se math random è maggiore di 0.5 allora metto 1 altrimenti 0
                        // Java tratta 1 e 0 come true e false
                        matrix[i][j] = Math.random() > 0.5 ? 1 : 0;
                    }
                }
                // salvo i risultati delle operazioni logiche tra gli elementi in riga
                int[] colRes = new int[rows];
                int res = 0;
                System.out.println("Matrice random dove 1 è true e 0 è false:");
                for(int i = 0; i < rows; i++){
                    for(int j = 0; j < cols; j++){
                        System.out.print(matrix[i][j] + " ");
                        res = res | matrix[i][j];
                    }
                    colRes[i] = res;
                    res = 0;
                    System.out.println();
                }
                // il valore iniziale di andRes è 1 perché è l'operatore identità dell'operatore logico AND, cioè se uno dei due operandi è 0 il risultato è 0
                int andRes = 1;
                System.out.println("result of the OR operation between the elements of each row:");
                for(int i = 0; i < rows; i++){
                    //stampo i risultati degli OR tra gli elementi di ogni riga
                    System.out.print(colRes[i] + " ");
                    // faccio l'AND tra ognuno dei risultati degli OR tra gli elementi di ogni riga
                    andRes = andRes & colRes[i];
                }
                System.out.println();
                System.out.println("Risultato finale degli AND:" + andRes);
                break;

            case 3:
                System.out.println("ESERCIZIO 3: inserire dimensioni di due matrici e sommarle con funzione ricorsiva");
                System.out.println("Inserire dimensioni della prima matrice: ");
                int rows1 = Integer.parseInt(System.console().readLine());
                int cols1 = Integer.parseInt(System.console().readLine());
                System.out.println("Inserire dimensioni della prima matrice: ");
                int rows2 = Integer.parseInt(System.console().readLine());
                int cols2 = Integer.parseInt(System.console().readLine());
                if(rows1 != rows2 || cols1 != cols2){
                    throw new Exception("Dimensioni delle matrici differenti.");
                }
                double[][] matrix1 = new double[rows1][cols1];
                double[][] matrix2 = new double[rows2][cols2];
                double[][] result = new double[rows1][cols1];
                Random rand = new Random();
                // riempio le matrici con numeri random
                for(int i = 0; i < rows1; i++){
                    for(int j = 0; j < cols1; j++){
                        matrix1[i][j] = rand.nextDouble();
                        matrix2[i][j] = rand.nextDouble();
                    }
                }
                // stampo le matrici
                System.out.println("Matrix 1: ");
                for(int i = 0; i < rows1; i++){
                    for(int j = 0; j < cols1; j++){
                        System.out.print(matrix1[i][j] + " ");
                    }
                    System.out.println();
                }
                System.out.println("Matrix 2: ");
                for(int i = 0; i < rows2; i++){
                    for(int j = 0; j < cols2; j++){
                        System.out.print(matrix2[i][j] + " ");
                    }
                    System.out.println();
                }
                System.out.println("Risultato: ");
                // -------------------------------------------------------------
                // chiamo la funzione che somma le due matrici, la funzione è ricorsiva e la trovate A FINE CODICE QUA SOTTO
                result = sumMatrices(matrix1, matrix2);
                // -------------------------------------------------------------
                // stampo la somma
                for(int i = 0; i < rows1; i++){
                    for(int j = 0; j < cols1; j++){
                        System.out.print(result[i][j] + " ");
                    }
                    System.out.println();
                }
                break;

            case 4:
                System.out.println("EXERCISE 4: Si realizzi un’applicazione Java per gestire gli ordini in un negozio online di articoli da mare");
                // Creo degli articoli
                ArticoloStandard a1 = new ArticoloStandard("a1", 10);
                ArticoloStandard a2 = new ArticoloStandard("a2", 20);
                ArticoloStandard a3 = new ArticoloStandard("a3", 30);
                ArticoloStandard[] articoli = {a1, a2, a3};
                ArticoloTris at = new ArticoloTris(articoli);
                ArticoloScontato as = new ArticoloScontato("as1", 100, 0.1);
                ArticoloStandard a4 = new ArticoloStandard("a4", 300);
                ArticoloStandard a5 = new ArticoloStandard("a4", 4000);
                // Creo un ordine
                Ordine o = new Ordine("o1");
                o.aggiungiArticolo(at);
                o.aggiungiArticolo(as);
                Ordine o2 = new Ordine("o2");
                o2.aggiungiArticolo(a4);
                o2.aggiungiArticolo(a5);
                // Creo un NegozioMare
                NegozioMare nm = new NegozioMare();
                nm.aggiungiOrdine(o);
                nm.aggiungiOrdine(o2);
                // Esporto gli 2 ordini
                nm.exportOrdini(2);
                break;
        
            default:
                break;
        }
    }

    private static double[][] sumMatrices(double[][] matrix1, double[][] matrix2){
        double[][] result = new double[matrix1.length][matrix1[0].length];
        sumMatricesHelper(matrix1, matrix2, result, 0, 0);
        return result;
    }
    private static void sumMatricesHelper(double[][] matrix1, double[][] matrix2, double[][] result, int i, int j) {
            // questo if effettua la chiamata ricorsica fino a quando non si è arrivati oltre l'ultima riga della matrice
            if(i < matrix1.length){
                // questo if effettua la chiamata ricorsiva fino a quando non si è arrivati oltre l'ultima colonna della matrice (altrimenti si passa alla riga successiva)
                if(j < matrix1[i].length){
                    // questa è la somma degli elementi delle due matrici
                    result[i][j] = matrix1[i][j] + matrix2[i][j];
                    // questo caso è la chiamata ricorsiva che scorre ogni riga sommando gli elementi delle due matrici
                    sumMatricesHelper(matrix1, matrix2, result, i, j + 1);
                } else { // si passa alla riga successiva
                    sumMatricesHelper(matrix1, matrix2, result, i + 1,0);
                }
            }
        }
}